#!/usr/bin/env bash
set -euo pipefail

RG="rg-jenkins-dev"
LOC="eastus"
VM="vm-jenkins"
IMAGE="Ubuntu2204"
SIZE="Standard_B2s"
ADMIN="azureuser"
SSH_KEY="${HOME}/.ssh/id_rsa.pub"
PUBLIC_IP_SKU="Standard"

echo ">> Creating resource group: ${RG} in ${LOC}"
az group create -n "${RG}" -l "${LOC}" >/dev/null

echo ">> Creating VM: ${VM} (${IMAGE}, ${SIZE})"
az vm create   -g "${RG}" -n "${VM}"   --image "${IMAGE}"   --size "${SIZE}"   --admin-username "${ADMIN}"   --ssh-key-values "${SSH_KEY}"   --public-ip-sku "${PUBLIC_IP_SKU}"   --verbose   | tee /tmp/vm_create_out.json >/dev/null

IP=$(jq -r '.publicIpAddress' /tmp/vm_create_out.json)
echo ">> Public IP: ${IP}"
echo "${IP}" > /tmp/jenkins_vm_ip.txt
