#!/usr/bin/env bash
set -euo pipefail

ADMIN="azureuser"
IP_FILE="/tmp/jenkins_vm_ip.txt"

if [[ ! -f "${IP_FILE}" ]]; then
  echo "Public IP file not found at ${IP_FILE}. Run scripts/create_vm.sh first."
  exit 1
fi

IP=$(cat "${IP_FILE}")
echo ">> SSH into VM ${IP} and install Jenkins LTS"

ssh -o StrictHostKeyChecking=no ${ADMIN}@${IP} <<'EOF'
set -euo pipefail
sudo apt-get update
sudo apt-get install -y fontconfig openjdk-17-jre wget gnupg  && wget -q -O - https://pkg.jenkins.io/debian-stable/jenkins.io-2023.key | sudo tee /usr/share/keyrings/jenkins-keyring.asc >/dev/null   && echo "deb [signed-by=/usr/share/keyrings/jenkins-keyring.asc] https://pkg.jenkins.io/debian-stable binary/" | sudo tee /etc/apt/sources.list.d/jenkins.list >/dev/null   && sudo apt-get update   && sudo apt-get install -y jenkins

sudo systemctl enable --now jenkins
echo ">> Jenkins status:"
sudo systemctl --no-pager status jenkins || true

echo ">> Initial admin password:"
sudo cat /var/lib/jenkins/secrets/initialAdminPassword || true
EOF

echo ">> Visit: http://${IP}:8080"
