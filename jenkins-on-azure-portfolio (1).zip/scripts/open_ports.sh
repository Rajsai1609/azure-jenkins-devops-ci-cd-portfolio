#!/usr/bin/env bash
set -euo pipefail
RG="rg-jenkins-dev"
VM="vm-jenkins"
PORT=8080

if [[ -z "${MY_IP:-}" ]]; then
  echo "MY_IP not set. Usage: MY_IP=$(curl -s ifconfig.me) bash scripts/open_ports.sh"
  exit 1
fi

echo ">> Allowing TCP/${PORT} from ${MY_IP}/32"
az vm open-port -g "${RG}" -n "${VM}" --port "${PORT}" --priority 200 --source-address-prefixes "${MY_IP}"
