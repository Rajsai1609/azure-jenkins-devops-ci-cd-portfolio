# Jenkins on Azure VM — Hands‑on Deployment

![Azure](https://img.shields.io/badge/Azure-Cloud-blue) ![Jenkins](https://img.shields.io/badge/Jenkins-CI%2FCD-red) ![Ubuntu](https://img.shields.io/badge/Ubuntu-22.04-orange) ![IaC](https://img.shields.io/badge/Scripts-Azure%20CLI-yellow)

A production‑style **Jenkins on Azure** setup I built from scratch. This repo includes the provisioning scripts, install steps, a sample pipeline, and a mini hardening playbook so recruiters/clients can **reproduce** the environment in minutes.

---

## 🎯 What I built
- **Azure VM (Ubuntu 22.04)** running Jenkins (LTS) with systemd service
- **Secure ingress** on TCP/8080 via NSG (optionally locked to my IP)
- **Sample Jenkins pipeline** (build → test → archive) to demonstrate CI
- **Docs**: setup, troubleshooting, backup, and reverse proxy with HTTPS

> **Use case:** developer or small team CI server you can spin up fast, then scale by adding Jenkins agents (VMs or containers).

---

## 🧭 Architecture (dev-friendly)
```
Developer → Internet → NSG (TCP/8080) → Azure VM (Ubuntu 22.04)
                                          └─ Jenkins LTS (Java 17, systemd)
Artifacts → Azure Disk / Blob (optional)
```

**VM size**: start with `Standard_B2s` for dev; move to `D2s_v5` as load grows.  
**Region**: `eastus` (change in scripts as needed).

---

## 🧪 Quickstart (reproduce locally)
> Prereqs: Azure CLI logged in (`az login`), SSH key at `~/.ssh/id_rsa.pub`.

```bash
# 1) Create resource group and VM
bash scripts/create_vm.sh

# 2) Allow port 8080 from your current IP (safer than *:8080)
MY_IP=$(curl -s ifconfig.me) bash scripts/open_ports.sh

# 3) SSH & install Jenkins (Java 17 + Jenkins LTS)
bash scripts/install_jenkins.sh

# 4) First time unlock
# Copy the output and finish setup at http://<public-ip>:8080
```

> The scripts echo the public IP at the end of step 1.

---

## 🧱 Repo map
```
jenkins-on-azure-portfolio/
├─ README.md
├─ scripts/
│  ├─ create_vm.sh          # az group/vm create (Ubuntu 22.04, B2s)
│  ├─ open_ports.sh         # NSG rule for 8080 restricted to $MY_IP
│  └─ install_jenkins.sh    # Java 17 + Jenkins LTS, systemd
├─ ci/
│  └─ Jenkinsfile           # demo pipeline (build/test/archive)
├─ hardening/
│  ├─ nginx-reverse-proxy.md
│  └─ backup-restore.md
├─ docs/
│  ├─ case-study.md         # STAR-style project write-up
│  └─ screenshots/          # replace placeholders with your images
├─ portfolio/
│  └─ index.md              # one‑page portfolio write‑up
├─ .gitignore
└─ LICENSE
```

---

## 🔐 Security & Ops (starter checklist)
- Restrict NSG **8080** to your office/home IP, or place behind **Nginx + HTTPS**
- Store `/var/lib/jenkins` on a **separate data disk**; snapshot regularly
- Create **least-privileged** service principals/credentials for cloud integrations
- Scale with **ephemeral build agents** (VMSS / containers) instead of a huge controller

---

## 🧩 Troubleshooting
- Jenkins page not loading? Check **NSG** rule and VM **UFW** status
- Cannot unlock? Read `/var/lib/jenkins/secrets/initialAdminPassword`
- Slow builds? Move from B‑series → D/E‑series; add agents; attach faster disk

---

## 📸 Screenshots (replace these)
- `docs/screenshots/azure-vm.png` — Azure VM overview
- `docs/screenshots/jenkins-dashboard.png` — Jenkins home
- `docs/screenshots/first-pipeline.png` — A successful pipeline run

---

## 📈 Results (example wording)
- **Time-to-first-pipeline**: ~15 minutes from blank subscription
- **Cost**: ~${5}–${20}/month (dev) depending on VM size and runtime
- **Outcome**: Consistent CI runs, artifact retention, and a secure entry point

See full write-up in [`docs/case-study.md`](docs/case-study.md).

---

## 🧰 Skills demonstrated
Azure • Jenkins • Linux • Networking/NSG • Bash • CI/CD • Hardening Basics

---

## 🚀 How to publish this for recruiters/clients
```bash
git init
git add .
git commit -m "Jenkins on Azure VM: hands-on deployment"
git branch -M main
git remote add origin git@github.com:<your-username>/jenkins-on-azure-portfolio.git
git push -u origin main
```
- Add repo topics: `azure`, `jenkins`, `devops`, `ci-cd`, `portfolio`
- Pin this repo on your GitHub profile
- Link it from your resume/LinkedIn/Notion
