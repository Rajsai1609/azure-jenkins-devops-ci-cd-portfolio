# Backup & restore Jenkins data

## Move Jenkins home to a data disk
1) **Attach a data disk** in Azure Portal (or CLI), then on the VM:
```bash
sudo lsblk
sudo mkfs.ext4 /dev/sdc   # example, confirm device
sudo mkdir -p /mnt/jenkins
sudo mount /dev/sdc /mnt/jenkins
sudo systemctl stop jenkins
sudo rsync -aHAX /var/lib/jenkins/ /mnt/jenkins/
sudo mv /var/lib/jenkins /var/lib/jenkins.bak
echo '/dev/sdc /var/lib/jenkins ext4 defaults 0 2' | sudo tee -a /etc/fstab
sudo mount -a
sudo systemctl start jenkins
```
2) **Snapshots**
- Take **VM disk snapshots** on a schedule.
- Test **restore** by attaching the snapshot to a new VM and verifying `/var/lib/jenkins` integrity.

## Ad‑hoc backup
```bash
sudo systemctl stop jenkins
sudo tar -czf /tmp/jenkins-backup-$(date +%F).tgz /var/lib/jenkins
sudo systemctl start jenkins
```
