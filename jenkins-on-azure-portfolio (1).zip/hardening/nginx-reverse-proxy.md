# Nginx reverse proxy for Jenkins (HTTPS)

> Goal: expose Jenkins at `https://your-domain/` securely.

## Steps
1) **DNS** → point `jenkins.yourdomain.com` to your VM public IP.
2) **Install Nginx + Certbot**
```bash
sudo apt update && sudo apt install -y nginx
sudo snap install core; sudo snap refresh core
sudo snap install --classic certbot
sudo ln -s /snap/bin/certbot /usr/bin/certbot
```
3) **Nginx site**
```nginx
server {
  listen 80;
  server_name jenkins.yourdomain.com;
  location / {
    proxy_pass http://127.0.0.1:8080;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
}
```
Enable and test:
```bash
sudo tee /etc/nginx/sites-available/jenkins <<'NG'
# (paste server block above)
NG
sudo ln -s /etc/nginx/sites-available/jenkins /etc/nginx/sites-enabled/jenkins
sudo nginx -t && sudo systemctl reload nginx
```
4) **TLS (Let’s Encrypt)**
```bash
sudo certbot --nginx -d jenkins.yourdomain.com --non-interactive --agree-tos -m you@example.com
```
