# Jenkins on Azure VM — Portfolio One‑Pager

**Role:** DevOps/Cloud Engineer • **Time:** 1 day • **Stack:** Azure, Ubuntu 22.04, Jenkins LTS, Bash, NSG

## Summary
Provisioned a secure Jenkins controller on Azure using reproducible scripts, delivered a functioning CI pipeline within minutes, and documented a scaling path with agents and HTTPS via Nginx.

## Highlights
- Azure CLI scripts to create VM and restrict ingress on 8080
- Jenkins LTS on Java 17 with systemd
- Sample pipeline (build → test → archive)
- Hardening docs: HTTPS reverse proxy, backup & restore

## Outcomes
- Time-to-first-pipeline: ~15 minutes
- Repeatable setup: 3 scripts
- Clear upgrade path: agents, larger VM sizes, data disk + snapshots

## Links
- Repo: https://github.com/<your-username>/jenkins-on-azure-portfolio
- Screenshots: see `docs/screenshots/`
