# Jenkins on Azure VM — Case Study (Hands‑on)

## 1) Situation
A small engineering team needed a fast, low‑cost CI server to automate builds and tests for multiple services without waiting for a full platform rollout.

## 2) Task
Design and deploy a Jenkins controller on Azure with secure access, a reproducible setup, and a sample pipeline — all documented so others can recreate it.

## 3) Actions
- Provisioned an **Ubuntu 22.04** VM (`Standard_B2s`) with **Azure CLI** scripts
- Opened **NSG 8080** restricted to my IP (no open 0.0.0.0/0 in prod)
- Installed **Jenkins LTS (Java 17)** as a systemd service
- Built a **sample pipeline** (build → test → archive) to demonstrate CI
- Wrote **hardening docs** (Nginx HTTPS, backups to data disk, snapshots)
- Organized a **GitHub‑ready repo** with clear README and scripts

## 4) Results
- **Time‑to‑first‑pipeline:** ~15 minutes from blank subscription
- **Repeatability:** End‑to‑end setup with three scripts
- **Security posture:** Ingress locked to IP; guidance for HTTPS via Nginx
- **Scalability path:** Add ephemeral agents (VMSS/containers) as load grows

> **Impact:** Demonstrates practical CI/CD skills on Azure that translate directly to production environments for SMEs and startups.

## 5) Tech & Skills
Azure, Jenkins, Linux (Ubuntu), Networking/NSG, Bash, CI/CD, systemd, basic hardening

## 6) Cost notes
- Dev VM (`B2s`) typically low monthly cost when used part‑time
- Scale to `D2s_v5` for heavier workloads; consider agents and storage options

## 7) Screenshots
Replace the placeholders in `docs/screenshots/` with actual images:
- Azure VM overview
- Jenkins dashboard
- First successful pipeline run
